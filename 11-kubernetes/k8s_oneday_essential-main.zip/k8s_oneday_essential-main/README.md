k8s_oneday
===
[Lab1 - Setting](https://github.com/wsjang619/k8s_oneday/tree/master/lab1)  
[Lab2 - Pod, Namespace, Replicaset, Deployment](https://github.com/wsjang619/k8s_oneday/tree/master/lab2)  
[Lab3 - Service, Ingress](https://github.com/wsjang619/k8s_oneday/tree/master/lab3)  
[Lab4 - Volume, Configmap, Secret](https://github.com/wsjang619/k8s_oneday/tree/master/lab4)  
[Lab5 - AutoScaling](https://github.com/wsjang619/k8s_oneday/tree/master/lab5)  
